import React, { useEffect, useState, useRef, useCallback } from "react";
import RegionPanel from "./components/RegionPanel";
import Timeline from "./components/Timeline";
import Anomalies from "./components/Anomalies";
import SnapshotViewer from "./components/SnapshotViewer";
import Controls from "./components/Controls";
import ConnectionStatus from "./components/ConnectionStatus";
import { ToastContainer, toast } from "react-toastify";
import { BarChart, Bar, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer } from "recharts";

const API = import.meta.env.VITE_API_URL || "http://localhost:8000";
const WS_BASE = import.meta.env.VITE_WS_URL || "ws://localhost:8000";

export default function App(){
  const [regions, setRegions] = useState({});
  const [deliveries, setDeliveries] = useState([]); // newest first
  const [anomalies, setAnomalies] = useState([]);
  const [wsStatus, setWsStatus] = useState("connecting");
  const wsRef = useRef(null);
  const deliveriesRef = useRef(new Map()); // package_id -> latest event (for dedupe)

  const MAX_EVENTS = 1000;

  // reconcile function: called periodically to fetch server state and prune/merge
  const reconcile = useCallback(async () => {
    try {
      const r = await fetch(`${API}/regions`);
      if (!r.ok) throw new Error("regions fetch failed");
      const regionsJson = await r.json();
      setRegions(regionsJson);

      const d = await fetch(`${API}/deliveries?limit=500`);
      const dj = await d.json();
      const recent = dj.recent || [];
      // merge: for each rec, dedupe by (src,dst,package_id,arrival_ts) uniqueness
      recent.forEach(rec => {
        const key = `${rec.package_id}@${rec.arrival_ts}`;
        if (!deliveriesRef.current.has(key)) {
          deliveriesRef.current.set(key, rec);
        }
      });
      // keep newest first sorted by arrival_ts desc
      const merged = Array.from(deliveriesRef.current.values())
        .sort((a,b)=> b.arrival_ts - a.arrival_ts)
        .slice(0, MAX_EVENTS);
      setDeliveries(merged);
      const a = await fetch(`${API}/anomalies?limit=200`);
      const aj = await a.json();
      setAnomalies(aj.recent || []);
      setWsStatus(prev => prev === "connecting" ? "connected" : prev);
    } catch (err) {
      setWsStatus("disconnected");
      console.error("reconcile error", err);
    }
  }, []);

  // WS init with reconnection
  useEffect(()=>{
    let mounted = true;
    let backoff = 1000;
    function connect(){
      const ws = new WebSocket(WS_BASE + "/ws");
      wsRef.current = ws;
      setWsStatus("connecting");
      ws.onopen = () => { setWsStatus("connected"); backoff = 1000; console.log("WS open"); toast.info("Live connection established") };
      ws.onmessage = (ev) => {
        try {
          const msg = JSON.parse(ev.data);
          if (msg.type === "delivery"){
            // dedupe by unique key
            const rec = msg.payload;
            const key = `${rec.package_id}@${rec.arrival_ts}`;
            if (!deliveriesRef.current.has(key)){
              deliveriesRef.current.set(key, rec);
              // ensure limit
              if (deliveriesRef.current.size > MAX_EVENTS) {
                // remove oldest
                const keys = Array.from(deliveriesRef.current.keys()).slice(0, deliveriesRef.current.size - MAX_EVENTS);
                keys.forEach(k=>deliveriesRef.current.delete(k));
              }
              // update state quietly
              setDeliveries(prev => [rec, ...prev].slice(0, MAX_EVENTS));
            }
          } else if (msg.type === "anomaly"){
            setAnomalies(prev => [msg.payload, ...prev].slice(0,200));
            toast.warn(`Anomaly: ${msg.payload.type}`, { autoClose: 4000 });
          }
        } catch(e){}
      };
      ws.onclose = () => {
        setWsStatus("disconnected");
        if (!mounted) return;
        setTimeout(()=>{ backoff = Math.min(30000, backoff*1.5); connect(); }, backoff);
      };
      ws.onerror = (e) => { console.error("WS err", e); ws.close(); };
    }
    connect();
    // initial reconcile and periodic
    reconcile();
    const interval = setInterval(reconcile, 5000);
    return ()=>{ mounted = false; clearInterval(interval); if (wsRef.current) wsRef.current.close(); };
  }, [reconcile]);

  const barData = Object.values(regions).map(r => ({ region: r.region, packages: r.packages, inflight: r.inflight }));

  return (
    <div className="container">
      <ToastContainer position="top-right" />
      <div className="header">
        <div style={{display:"flex",gap:12,alignItems:"center"}}>
          <h1 style={{margin:0}}>Global Delivery Simulator</h1>
          <div style={{fontSize:13,color:"var(--muted)"}}>live demo</div>
        </div>
        <div style={{display:"flex",gap:12,alignItems:"center"}}>
          <ConnectionStatus status={wsStatus} />
          <Controls onRefresh={reconcile} />
        </div>
      </div>

      <div className="grid">
        <div>
          <div className="card" style={{marginBottom:12}}>
            <h3 className="h3">Packages by Region</h3>
            <div style={{height:200}}>
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={barData}>
                  <XAxis dataKey="region" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="packages" fill="#2563eb" />
                  <Bar dataKey="inflight" fill="#f97316" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          <RegionPanel regions={regions} />

          <div style={{height:12}}/>

          <Timeline deliveries={deliveries} anomalies={anomalies} />
        </div>

        <div style={{display:"flex", flexDirection:"column", gap:12}}>
          <Anomalies anomalies={anomalies} />
          <SnapshotViewer api={API} />
        </div>
      </div>
    </div>
  );
}
